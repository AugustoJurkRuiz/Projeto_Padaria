import { Component } from '@angular/core';

@Component({
  selector: 'app-footer', // Define o seletor do componente
  templateUrl: './footer.component.html', // Caminho para o template HTML
  styleUrls: ['./footer.component.css'] // Caminho para o arquivo de estilos CSS
})
export class FooterComponent {
  // Componente de rodapé vazio, pronto para implementação futura
}