import { Component } from '@angular/core';

@Component({
  selector: 'app-nav', // Define o seletor do componente
  templateUrl: './nav.component.html', // Caminho para o template HTML
  styleUrls: ['./nav.component.css'] // Caminho para o arquivo de estilos CSS
})
export class NavComponent {
  // Componente de navegação vazio, pronto para implementação futura
}