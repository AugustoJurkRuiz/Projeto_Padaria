export interface Endereco {
    endId?: number;
    endRua: string;
    endNumero: string;
    endCidade: string;
    endCep: string;
    endEstado: string;
}
