// Define uma interface chamada contato
export interface Contato{
    conId?: number
    conTelefoneComercial: string
    conCelular: string
    conEmail: string
}